﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListView.Items.Add("mum")
        ListView.Items.Add("daddy")
        ListView.Items.Add("donkey")
        ListView.Items.Add("cow")
        ListView.Items.Add("fish")
        ListView.Items.Add("goat")
        ListView.Items.Add("bird")
        ListView.Items.Add("pot")
        ListView.Items.Add("car")
        ListView.Items.Add("food")
    End Sub
End Class
